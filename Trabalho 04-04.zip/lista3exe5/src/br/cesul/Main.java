package br.cesul;

public class Main {
    public static void main(String[] args) {
        // Criando alguns contatos
        Contact contato1 = new Contact("João", "Rua A, 123", "Masculino", "123456789", "987654321", "joao@example.com");
        Contact contato2 = new Contact("Maria", "Rua B, 456", "Feminino", "987654321", "123456789", "maria@example.com");

        // Criando a agenda
        ContactBook agenda = new ContactBook();

        // Incluindo os contatos na agenda
        agenda.incluirContato(contato1);
        agenda.incluirContato(contato2);

        // Visualizando os contatos cadastrados
        agenda.visualizarContatos();

        // Excluindo um contato
        agenda.excluirContato("Maria");

        // Visualizando os contatos novamente após exclusão
        agenda.visualizarContatos();
    }
}