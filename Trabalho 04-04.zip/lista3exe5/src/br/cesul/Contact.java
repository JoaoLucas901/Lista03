package br.cesul;

class Contact {
    private String nome;
    private String endereco;
    private String sexo;
    private String telefone;
    private String celular;
    private String email;

    // Construtor
    public Contact(String nome, String endereco, String sexo, String telefone, String celular, String email) {
        this.nome = nome;
        this.endereco = endereco;
        this.sexo = sexo;
        this.telefone = telefone;
        this.celular = celular;
        this.email = email;
    }

    // Métodos getters para os atributos do contato
    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getSexo() {
        return sexo;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCelular() {
        return celular;
    }

    public String getEmail() {
        return email;
    }
}

// Classe que representa a agenda de contatos
class ContactBook {
    private static final int MAX_CONTATOS = 100; // Define o tamanho máximo da agenda
    private Contact[] contatos; // Array para armazenar os contatos
    private int numContatos; // Número atual de contatos na agenda

    // Construtor
    public ContactBook() {
        contatos = new Contact[MAX_CONTATOS];
        numContatos = 0;
    }

    // Método para incluir um novo contato
    public void incluirContato(Contact contato) {
        if (numContatos < MAX_CONTATOS) {
            contatos[numContatos] = contato;
            numContatos++;
        } else {
            System.out.println("A agenda está cheia. Não é possível adicionar mais contatos.");
        }
    }

    // Método para visualizar todos os contatos
    public void visualizarContatos() {
        if (numContatos == 0) {
            System.out.println("A agenda está vazia.");
        } else {
            System.out.println("Contatos cadastrados na agenda:");
            for (int i = 0; i < numContatos; i++) {
                System.out.println("Nome: " + contatos[i].getNome());
                System.out.println("Endereço: " + contatos[i].getEndereco());
                System.out.println("Sexo: " + contatos[i].getSexo());
                System.out.println("Telefone: " + contatos[i].getTelefone());
                System.out.println("Celular: " + contatos[i].getCelular());
                System.out.println("E-mail: " + contatos[i].getEmail());
                System.out.println("-----------------------------");
            }
        }
    }

    // Método para excluir um contato
    public void excluirContato(String nome) {
        for (int i = 0; i < numContatos; i++) {
            if (contatos[i].getNome().equals(nome)) {
                // Move todos os contatos para trás para preencher o espaço
                for (int j = i; j < numContatos - 1; j++) {
                    contatos[j] = contatos[j + 1];
                }
                contatos[numContatos - 1] = null; // Remove a referência ao último contato
                numContatos--;
                System.out.println("Contato '" + nome + "' excluído com sucesso.");
                return;
            }
        }
        System.out.println("Contato '" + nome + "' não encontrado na agenda.");
    }
}