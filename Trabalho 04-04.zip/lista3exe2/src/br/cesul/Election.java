package br.cesul;

public class Election {

    public double candidateA;

    public double candidateB;

    public double voteWhite;

    public double voteNull;

    public Election(double candidateA, double candidateB, double voteWhite, double voteNull) {
        this.candidateA = candidateA;
        this.candidateB = candidateB;
        this.voteWhite = voteWhite;
        this.voteNull = voteNull;
    }
}
