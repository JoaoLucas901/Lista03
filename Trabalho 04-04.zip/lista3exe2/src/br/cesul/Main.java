package br.cesul;

public class Main {

    public static void main(String[] args) {
        Election election = new Election(50, 76, 21, 10);
        System.out.println("o numero de votos do candidato A foi " + election.candidateA);
        System.out.println("o numero de votos do candidato B foi: " + election.candidateB);
        System.out.println("o numero de votos em branco foram: " + election.voteWhite);
        System.out.println("o numero de votos nulos foram: " + election.voteNull);
    }
}
