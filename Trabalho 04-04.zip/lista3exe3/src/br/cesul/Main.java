package br.cesul;

public class Main {

    public static void main(String[] args) {
        double temperaturaFahrenheit = 77.0;
        double temperaturaCelsius = 25.0;

        double celsius = TemperatureConverter.converterFahrenheitParaCelsius(temperaturaFahrenheit);
        System.out.printf("%.1f graus Fahrenheit equivalem a %.1f graus Celsius.\n", temperaturaFahrenheit, celsius);

        double fahrenheit = TemperatureConverter.converterCelsiusParaFahrenheit(temperaturaCelsius);
        System.out.printf("%.1f graus Celsius equivalem a %.1f graus Fahrenheit.\n", temperaturaCelsius, fahrenheit);
    }
}