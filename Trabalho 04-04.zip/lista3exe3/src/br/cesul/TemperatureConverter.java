package br.cesul;

public class TemperatureConverter {

    private TemperatureConverter() {}

    public static double converterFahrenheitParaCelsius(double fahrenheit) {
        return (fahrenheit - 32) / 1.8;
    }

    public static double converterCelsiusParaFahrenheit(double celsius) {
        return (celsius * 1.8) + 32;
    }
}