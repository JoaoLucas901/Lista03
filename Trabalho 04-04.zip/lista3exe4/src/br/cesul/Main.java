package br.cesul;

public class Main {

    public static void main(String[] args) {
        Coordenada ponto1 = new Coordenada(2.5, 3.1);
        Coordenada ponto2 = new Coordenada(-1.7, 4.2);

        System.out.printf("Ponto 1: %s\n", ponto1);
        System.out.printf("Quadrante do Ponto 1: %d\n", ponto1.getQuadrante());

        System.out.printf("Ponto 2: %s\n", ponto2);
        System.out.printf("Quadrante do Ponto 2: %d\n", ponto2.getQuadrante());

        double distancia = ponto1.calcularDistancia(ponto2);
        System.out.printf("Distância entre os pontos: %.2f\n", distancia);
    }
}
